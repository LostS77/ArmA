#ifdef description

	#include "vip_cmn\resource\vip_dlg_defaults.hpp"
	#include "vip_asp\resource\vip_asp_dlg.hpp"

#endif

#ifdef description_functions

	#include "vip_cmn\fn\vip_cmn_fnc.hpp"
	#include "vip_asp\fn\vip_asp_fnc.hpp"

#endif

#ifdef description_titles

	#include "vip_asp\resource\vip_asp_rscTitles.hpp"
	
#endif