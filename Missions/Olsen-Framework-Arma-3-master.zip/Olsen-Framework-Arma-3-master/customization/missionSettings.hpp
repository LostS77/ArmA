author = "Olsen"; //Author of the mission
loadScreen = "core\uoLogo.jpg"; //Sets the image displayed during the loading screen
onLoadMission = "Test mission"; //Text displayed under the image during the loading screen

class Header {
	
	gameType = Coop;
	minPlayers = 1;
	maxPlayers = 9; //maxPlayers must always be accurate to the amount of playable units
	
};